package com.ritesh.bakare0.Custom.Form;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomFormApplication.class, args);
	}

}
