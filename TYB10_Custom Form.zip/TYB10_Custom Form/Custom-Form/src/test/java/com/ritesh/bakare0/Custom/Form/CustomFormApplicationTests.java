package com.ritesh.bakare0.Custom.Form;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
